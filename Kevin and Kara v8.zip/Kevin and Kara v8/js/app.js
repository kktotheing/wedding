// This gives anmiation to the nav scroll, shrinking the text and height.

$(window).scroll(function () {
	var offset = $(window).scrollTop();

	if (offset > 30) {
		$('header').addClass('header-offset')
	} else {
		$('header').removeClass('header-offset')
	}
})


 /* 

ANIMATIONS FOR SCROLL AND CLOUDS from https://codepen.io/MarcelSchulz/pen/lCvwq

*/

jQuery(document).ready(function(){
  $(window).scroll(function(e){
    parallaxScroll();
  });
   
  function parallaxScroll(){
    var scrolled = $(window).scrollTop();
    $('#parallax-bg-1').css('top',(0-(scrolled*.25))+'px');
    $('#parallax-bg-2').css('top',(0-(scrolled*.4))+'px');
    $('#parallax-bg-3').css('top',(0-(scrolled*.75))+'px');
  }
 
 }); 